library(lmtest)
library(tidyverse)
library(sandwich)
library(texreg)
library(marginaleffects)
library(rnaturalearth)


# import data
load("mining_violence_dat.rda")


###################################################################
###################################################################
#
#               Mining and violence in Latin America: 
#     The state’s coercive responses to anti-mining resistance
#
#                 Moises Arce & Camilo Nieto-Matiz
#                 camilo.nieto-matiz@utsa.edu
###################################################################
###################################################################

 
#=========================================
#          logit  models                 #  
#=========================================

#------ any event --------

#### OPPORTUNITIES ####
summary(l1<-glm(any_event~ttime_mean+nlightscalib1+popdens1+drug1+
                        drought1+WorkType+active_year,
                        family=binomial,
                      data=mining))
l1_<-coeftest(l1, vcov = vcovHC, cluster = ~Country)

#### MOTIVES ####
summary(l2<-glm(any_event~excluded1d+lootable+popdens1+drug1+
                        drought1+WorkType+active_year,
                        family=binomial,
                      data=mining))
l2_<-coeftest(l2, vcov = vcovHC, cluster = ~Country)



#### MOTIVES AND OPPORTUNITIES ####
summary(l3<-glm(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                        drug1+drought1+WorkType+active_year,
                        family=binomial,
                      data=mining))
l3_<-coeftest(l3,vcov = vcovHC, cluster = ~Country)

#plot excluded
plot_predictions(l3, condition = c("excluded1d"), vcov = "HC1")+
  xlab('Indigenous involvement')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()



#plot lootable
plot_predictions(l3, condition = c("lootable"), vcov = "HC1")+
  xlab('Lootable resources')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()


screenreg(list(l1_,l2_,l3_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))





#------ different types of tactics --------

#### JUDICIALIZATION ####
summary(jud3log<-glm(Judicializacion~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                          drug1+drought1+WorkType+active_year,
                         family=binomial,
                        data=mining))
jud3log_<-coeftest(jud3log, vcov = vcovHC, cluster = ~Country)

#plot
plot_predictions(jud3log, condition = c("excluded1d"), vcov = "HC1")+
  xlab('Indigenous involvement')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()


plot_predictions(jud3log, condition = c("lootable"), vcov = "HC1")+
  xlab('Lootable resources')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()


#### FORCE ####
summary(fuerza3log<-glm(Usodefuerza~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                             drug1+drought1+WorkType+active_year,
                             family=binomial,
                           data=mining))
fuerza3log_<-coeftest(fuerza3log, vcov = vcovHC, cluster = ~Country)

#plot
plot_predictions(fuerza3log, condition = c("excluded1d"), vcov = "HC1")+
  xlab('Indigenous involvement')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()

plot_predictions(fuerza3log, condition = c("lootable"), vcov = "HC1")+
  xlab('Lootable resources')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()



#### THREAT ####
summary(ame3log<-glm(Amenazas~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                          drug1+drought1+WorkType+active_year,
                        family=binomial,
                        data=mining))
ame3log_<-coeftest(ame3log,vcov = vcovHC, cluster = ~Country)

plot_predictions(ame3log, condition = c("excluded1d"), vcov = "HC1")+
  xlab('Indigenous involvement')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()

plot_predictions(ame3log, condition = c("lootable"), vcov = "HC1")+
  xlab('Lootable resources')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()

screenreg(list(jud3log_,ame3log_,fuerza3log_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))








#------ types of locations --------


#### AGRICULTURE ####
summary(agr1<-glm(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                    drug1+drought1+WorkType+active_year,
                  family = binomial,
                  data=mining, subset = agr1==0))
agr1_<-coeftest(agr1,vcov = vcovHC, cluster = ~Country)

summary(agr2<-glm(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                    drug1+drought1+WorkType+active_year,
                  family = binomial,
                  data=mining, subset = agr1==1))
agr2_<-coeftest(agr2,vcov = vcovHC, cluster = ~Country)


## 
p1_<-  plot_predictions(agr1, condition = c("excluded1d"), vcov = "HC1", draw=F) %>% 
  filter(excluded1d==1) %>%
  select(estimate, conf.low,conf.high) %>%
  dplyr::mutate(type="Low \nagriculture",
                term="excluded1d1")  
p2_<-  plot_predictions(agr2, condition = c("excluded1d"), vcov = "HC1", draw=F) %>% 
  filter(excluded1d==1) %>%
  select(estimate, conf.low,conf.high) %>%
  mutate(type="High \nagriculture",
                term="excluded1d1") 
plot_agr <- rbind(p1_,p2_)


plot_agr %>% 
  ggplot(aes(y = factor(type, level=c('Low \nagriculture',  'High \nagriculture')), x = estimate)) + 
  geom_errorbarh(aes(xmin = conf.low, xmax = conf.high),
                 position = position_dodge(width = .15),
                 size=.7, height=0) +
  geom_point()+ 
  ylab('') + coord_flip()+ 
  theme_bw()   + xlab('') + xlim(0,.5)




#### WATER ####
summary(wat1<-glm(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                          drug1+drought1+WorkType+active_year,
                          family = binomial,
                        data=mining, subset = water1_d==0))
wat1_<-coeftest(wat1,vcov = vcovHC, cluster = ~Country)

summary(wat2<-glm(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                          drug1+drought1+WorkType+active_year,
                          family = binomial,
                        data=mining, subset = water1_d==1))
wat2_<-coeftest(wat2,vcov = vcovHC, cluster = ~Country)


## 
p3_<-  plot_predictions(wat1, condition = c("excluded1d"), vcov = "HC1", draw=F) %>% 
  filter(excluded1d==1) %>%
  select(estimate, conf.low,conf.high) %>%
  mutate(type="Low \nwater",
                term="excluded1d1")  
p4_<-  plot_predictions(wat2, condition = c("excluded1d"), vcov = "HC1", draw=F) %>% 
  filter(excluded1d==1) %>%
  select(estimate, conf.low,conf.high) %>%
  mutate(type="High \nwater",
                term="excluded1d1") 
plot_wat <- rbind(p3_,p4_)


plot_wat %>% 
  ggplot(aes(y = factor(type, level=c('Low \nwater',  'High \nwater')), x = estimate)) + 
  geom_errorbarh(aes(xmin = conf.low, xmax = conf.high),
                 position = position_dodge(width = .15),
                 size=.7, height=0) +
  geom_point()+ 
  ylab('') + coord_flip()+ 
  theme_bw()   + xlab('') + xlim(0,.5)

screenreg(list(agr1,agr2,wat1,wat2),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))







#=========================================
#         plot mining locations          #  
#=========================================



# world map
world <- ne_countries(scale = "medium", returnclass = "sf")

world %>% 
  ggplot() + 
  geom_sf(color = "black", fill = "white",size=.2) +
  geom_sf(data=mining, 
             alpha=.2, color="lightskyblue4", lwd=1.1) +
  geom_sf(data=subset(mining, Sum>0),
             alpha=.6, color="red", shape=3, lwd=.7, stroke=.4) +
  coord_sf(xlim = c(-120, -30), ylim = c(-60, 40), expand = FALSE)+
  xlab('')+ylab('')+theme_bw()+
  theme(axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks = element_blank())
 
 



 
