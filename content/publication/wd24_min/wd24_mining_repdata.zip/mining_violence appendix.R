library(lmtest)
library(tidyverse)
library(sandwich)
library(texreg)
library(estimatr)
library(marginaleffects)
library(rnaturalearth)



# import data
load("mining_violence_dat.rda")


###################################################################
###################################################################
#                       A P P E N D I X
#               Mining and violence in Latin America: 
#     The state’s coercive responses to anti-mining resistance
#
#                 Moises Arce & Camilo Nieto-Matiz
#                 camilo.nieto-matiz@utsa.edu
###################################################################
###################################################################



###############################################################
# Controlling for rough terrain and infant mortality rates
###############################################################

#------ any event --------

summary(l1c<-glm(any_event~ttime_mean+nlightscalib1+popdens1+drug1+
                   drought1+WorkType+imr1+mountains1+active_year,
                 family=binomial, data=mining))
l1c_<-coeftest(l1c, vcov = vcovCL, cluster = ~Country)

summary(l2c<-glm(any_event~excluded1d+lootable+popdens1+drug1+
                   drought1+WorkType+imr1+mountains1+active_year,
                 family=binomial, data=mining))
l2c_<-coeftest(l2c, vcov = vcovCL, cluster = ~Country)

summary(l3c<-glm(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                   drug1+drought1+WorkType+imr1+mountains1+active_year,
                 family=binomial, data=mining))
l3c_<-coeftest(l3c, vcov = vcovCL, cluster = ~Country)


#plot excluded
plot_predictions(l3c, condition = c("excluded1d"), vcov = "HC1")+
  xlab('Indigenous involvement')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()
 

#plot lootable
plot_predictions(l3c, condition = c("lootable"), vcov = "HC1")+
  xlab('Lootable resources')+ylab('Coercive response')+ylim(0,.4)+
  theme(plot.title = element_blank()) +theme_bw()

screenreg(list(l1c_,l2c_,l3c_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))



#------ different types of tactics --------

summary(jud3logc<-glm(Judicializacion~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                        drug1+drought1+WorkType+imr1+mountains1+active_year,
                      family=binomial, data=mining))
jud3logc_<-coeftest(jud3logc, vcov = vcovCL, cluster = ~Country)

summary(fuerza3logc<-glm(Usodefuerza~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                           drug1+drought1+WorkType+imr1+mountains1+active_year,
                         family=binomial,data=mining))
fuerza3logc_<-coeftest(fuerza3logc, vcov = vcovCL, cluster = ~Country)

summary(ame3logc<-glm(Amenazas~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                        drug1+drought1+WorkType+imr1+mountains1+active_year,
                      family=binomial, data=mining))
ame3logc_<-coeftest(ame3logc, vcov = vcovHC, cluster = ~Country)

screenreg(list(jud3logc_,ame3logc_,fuerza3logc_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))






##################################################################
#  Linear probability models: Results using OLS specification
##################################################################
 

#------ any event --------

summary(b1<-lm_robust(any_event~ttime_mean+nlightscalib1+popdens1+drug1+
                        drought1+WorkType+active_year,
                      data=mining, clusters = Country))

summary(b2<-lm_robust(any_event~excluded1d+lootable+popdens1+drug1+
                        drought1+WorkType+active_year,
                      data=mining, clusters = Country))

summary(b3<-lm_robust(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                        drug1+drought1+WorkType+active_year,
                      data=mining, clusters = Country))

screenreg(list(b1,b2,b3),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))


 
#------ different types of tactics --------
 

summary(jud3<-lm_robust(Judicializacion~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                          drug1+drought1+WorkType+active_year,
                        data=mining, clusters = Country))

summary(fuerza3<-lm_robust(Usodefuerza~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                             drug1+drought1+WorkType+active_year,
                           data=mining, clusters = Country))

summary(ame3<-lm_robust(Amenazas~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                          drug1+drought1+WorkType+active_year,
                        data=mining, clusters = Country))

screenreg(list(jud3,ame3,fuerza3),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))

 


#------ types of locations --------

# agriculture  
summary(lp_agr1<-lm_robust(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                    drug1+drought1+WorkType+active_year,
                  clusters = Country, data=mining, subset = agr1==0))

summary(lp_agr2<-lm_robust(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                    drug1+drought1+WorkType+active_year,
                  clusters = Country, data=mining, subset = agr1==1))

# water
summary(lp_wat1<-lm_robust(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                       drug1+drought1+WorkType+active_year,
                     clusters = Country, data=mining, subset = water1_d==0))

summary(lp_wat2<-lm_robust(any_event~excluded1d+lootable+ttime_mean+nlightscalib1+popdens1+
                       drug1+drought1+WorkType+active_year,
                     clusters = Country, data=mining, subset = water1_d==1))

screenreg(list(lp_agr1,lp_agr2,lp_wat1,lp_wat2),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))







############################# 
#   No spatial contiguity
############################# 


#------ any event --------

summary(l1n<-glm(any_event~ttime_mean+nlights_calib_mean+popdens+drug_y+
                   droughtyr_spi+WorkType+active_year,
                 family=binomial, data=mining))
l1n_<-coeftest(l1n, vcov = vcovHC, cluster = ~Country)


summary(l2n<-glm(any_event~excludedd+lootable+popdens+drug_y+
                   droughtyr_spi+WorkType+active_year,
                 family=binomial, data=mining))
l2n_<-coeftest(l2n, vcov = vcovHC, cluster = ~Country)


summary(l3n<-glm(any_event~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                   drug_y+droughtyr_spi+WorkType+active_year,
                 family=binomial, data=mining))
l3n_<-coeftest(l3n,vcov = vcovHC, cluster = ~Country)


screenreg(list(l1n_,l2n_,l3n_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))



#------ different types of tactics --------

summary(jud3logn<-glm(any_event~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                        drug_y+droughtyr_spi+WorkType+active_year,
                      family=binomial, data=mining))
jud3logn_<-coeftest(jud3logn,vcov = vcovHC, cluster = ~Country)


summary(fuerza3logn<-glm(Usodefuerza~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                           drug_y+droughtyr_spi+WorkType+active_year,
                         family=binomial, data=mining))
fuerza3logn_<-coeftest(fuerza3logn, vcov = vcovHC, cluster = ~Country)


summary(ame3logn<-glm(Amenazas~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                        drug_y+droughtyr_spi+WorkType+active_year,
                      family=binomial, data=mining))
ame3logn_<-coeftest(ame3logn,vcov = vcovHC, cluster = ~Country)


screenreg(list(jud3logn_,ame3logn_,fuerza3logn_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))




#------ types of locations --------

# agriculture
summary(agr1n<-glm(any_event~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                     drug_y+droughtyr_spi+WorkType+active_year,
                   family = binomial, data=mining, subset = agr1==0))
agr1n_<-coeftest(agr1n,vcov = vcovHC, cluster = ~Country)

summary(agr2n<-glm(any_event~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                     drug_y+droughtyr_spi+WorkType+active_year,
                   family = binomial, data=mining, subset = agr1==1))
agr2n_<-coeftest(agr2n,vcov = vcovHC, cluster = ~Country)


# water
summary(wat1n<-glm(any_event~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                     drug_y+droughtyr_spi+WorkType+active_year,
                   family = binomial, data=mining, subset = water1_d==0))
wat1n_<-coeftest(wat1n,vcov = vcovHC, cluster = ~Country)

summary(wat2n<-glm(any_event~excludedd+lootable+ttime_mean+nlights_calib_mean+popdens+
                     drug_y+droughtyr_spi+WorkType+active_year,
                   family = binomial, data=mining, subset = water1_d==1))
wat2n_<-coeftest(wat2n,vcov = vcovHC, cluster = ~Country)

screenreg(list(agr1n_,agr2n_,wat1n_,wat2n_),include.ci=F, 
          stars = c(0.01, 0.05, 0.1))














 